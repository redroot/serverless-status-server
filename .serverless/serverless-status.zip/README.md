# Serverless Status Server

A serverless implementation of a simple status server that features:

- Homepage contain all current status keys, messages and last updated time
- Ability to filter for ok, warning, and critical statuses
- Ability to search for specific status key
- Ability to POST to an endpoint to update a status, using a token for auth
- Uses DynamoDB to store statuses

By default it runs on a 'dev' stage but you can set the stage to whatever value you want.

## Getting Started

- Fork the codebase!
- Firstly set up a [AWS profile with the correct access permissions for serverless](https://serverless.com/framework/docs/providers/aws/guide/credentials/).
- Either export the access key id and secret access key to your environment, or make use of `~/.aws/credentials` and `direv` using a `.envrc` file - [see example](https://medium.com/blechatech/how-to-setup-aws-credentials-for-new-code-cc80c44cc67).

## Local Development

## Testing

## Deployment

## Contributing


## TODO

- get all routes working and returning something
- get setup in prod with api gateway and secret dynamo tokens for different envs
- add html views and routing for routes
- add dynamodb backend

## TODO V2

- Cron style status tasks within this repo with common DSL
